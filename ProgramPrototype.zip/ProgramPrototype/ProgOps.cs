﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DatabaseConnection_G2_sp23
{
    class ProgOps
    {
        
        public static TeacherMain TeachForm = new TeacherMain();
        public static AdminMain AdminForm = new AdminMain();
        public static OfficerMain OfficerForm = new OfficerMain();
        public static Student StudentForm = new Student();
        public static Guardian GuardianForm = new Guardian();
        
        

        private const string CONNECT_STRING = @"Server=3.130.26.194;Database= inew2330gsp23; user Id= team2sp232330;" + "password= HF6ukL7sQs;";

        private static SqlConnection sqlDatabase = new SqlConnection(CONNECT_STRING);

        private static SqlCommand sqlResultsCommand;

        private static SqlDataAdapter daResults = new SqlDataAdapter();

        private static DataTable dtResultsTable = new DataTable();

        /* public static DataTable DTresultsTable
         {
             get { return dtResultsTable; }
             set { dtResultsTable = value; }
         }*/

    public static void OpenDatabase()
        {
           
            sqlDatabase.Open();
            
            MessageBox.Show("Connection to database was opened successfully", "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }
        public static void CloseDatabase()
        {
            
            sqlDatabase.Close();
            
            sqlDatabase.Dispose();
            MessageBox.Show("Connection to database was closed successfully", "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public static String DBLogin(string login, string password) 
        { 
            string sqlQuery = "SELECT SecurityLevel FROM team2sp232330.Logins WHERE Username = "+ "'"+login+ "'"+" AND UserPassword = "+"'"+password +"';";
            sqlResultsCommand = null;
            string results = "Invalid Login"; 
            SqlDataReader dReader;
            try
            {
                sqlResultsCommand = new SqlCommand(sqlQuery, sqlDatabase);
                try
                {
                    dReader = sqlResultsCommand.ExecuteReader();
                    while (dReader.Read())
                    {
                        results = dReader.GetValue(0).ToString();
                    }
                    dReader.Close();
                    sqlResultsCommand.Dispose();
                }
                catch (Exception ex) {  }
                return results;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Error in SQL", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            
            sqlResultsCommand.Dispose();
            
            return "uh oh";

        }
        public static String DBLoginID(string login, string password)
        {
            string sqlQuery = "SELECT LoginID FROM team2sp232330.Logins WHERE Username = " + "'" + login + "'" + " AND UserPassword = " + "'" + password + "';";
            sqlResultsCommand = null;
            string results = "Invalid Login";
            SqlDataReader dReader;
            try
            {
                sqlResultsCommand = new SqlCommand(sqlQuery, sqlDatabase);
                try
                {
                    
                    dReader = sqlResultsCommand.ExecuteReader();
                    while (dReader.Read())
                    {
                        results = dReader.GetValue(0).ToString();
                    }
                    dReader.Close();
                    sqlResultsCommand.Dispose();
                }
                catch (Exception ex) { }
                return results;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Error in SQL", MessageBoxButtons.OK, MessageBoxIcon.Error); }

            sqlResultsCommand.Dispose();

            return "uh oh";

        }

        public static void DBCFillStudent(string staffID,string courseNumber,DataGridView DVGResults)
        {
            string sqlQuery = "SELECT C.StudentID, Co.CourseNumber, C.StudentSeatNumber, C.Homework, C.Quiz, C.Lab, C.ClassParticipation, C.GroupProject " +
            "FROM team2sp232330.Class C " +
            "JOIN team2sp232330.Course Co ON C.CourseNumber = Co.CourseNumber " +
            "WHERE Co.StaffID = '" +staffID+"' AND Co.CourseNumber = '" +courseNumber + "';";
            sqlResultsCommand = null;
            daResults = new SqlDataAdapter();
            dtResultsTable = new DataTable();

            try
            {
                sqlResultsCommand = new SqlCommand(sqlQuery, sqlDatabase);
                daResults.SelectCommand = sqlResultsCommand;
                daResults.Fill(dtResultsTable);
                DVGResults.DataSource = dtResultsTable;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Error in SQL", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            sqlResultsCommand.Dispose();
            daResults.Dispose();
            dtResultsTable.Dispose();
        }
        public static string SingleITemQuerry(string sqlQuery) 
        {
            sqlResultsCommand = null;
            string results = "Invalid Querry";
            SqlDataReader dReader;
            try
            {
                sqlResultsCommand = new SqlCommand(sqlQuery, sqlDatabase);
                try
                {
                    dReader = sqlResultsCommand.ExecuteReader();
                    while (dReader.Read())
                    {
                        results = dReader.GetValue(0).ToString();
                    }
                    dReader.Close();
                    sqlResultsCommand.Dispose();
                }
                catch (Exception ex) { }
                return results;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Error in SQL", MessageBoxButtons.OK, MessageBoxIcon.Error); }

            sqlResultsCommand.Dispose();

            return "uh oh";
        }
    }
}
