﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseConnection_G2_sp23
{
    
    public partial class Login : Form
    {

        
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            //opens database
            ProgOps.OpenDatabase();
            
        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            //closes database
            ProgOps.CloseDatabase();
            Application.Exit();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            //Application.Exit();
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string staffID, studentID, guardianID;
            staffID = "";
            studentID = "";
            guardianID = "";
            string login = tbxUsername.Text;
            string password = tbxPassword.Text;
            string securityLevel = ProgOps.DBLogin(login,password);
            string loginID = ProgOps.DBLoginID(login, password);
            switch (securityLevel) 
            {
                case "teacher":
                    staffID = ProgOps.SingleITemQuerry("SELECT StaffID FROM team2sp232330.staff WHERE LoginID = '" + loginID + "';");
                    ProgOps.TeachForm.ShowDialog();
                    
                    break;
                case "admin":
                    ProgOps.AdminForm.ShowDialog();
                    
                    break;
                case "officer":
                    ProgOps.OfficerForm.ShowDialog();
                    
                    break;
                case "student":
                    studentID = ProgOps.SingleITemQuerry("SELECT StudentID FROM team2sp232330.student WHERE LoginID = '" + loginID + "';");
                    ProgOps.StudentForm.ShowDialog();
                    
                    break;
                case "guardian":
                    studentID = ProgOps.SingleITemQuerry("SELECT StudentID FROM team2sp232330.guardian WHERE LoginID = '" + loginID + "';");
                    guardianID = ProgOps.SingleITemQuerry("SELECT GuardianID FROM team2sp232330.guardian WHERE LoginID = '" + loginID + "';");
                    ProgOps.StudentForm.ShowDialog();
                    
                    break;
            }
            
        }
    }
}
