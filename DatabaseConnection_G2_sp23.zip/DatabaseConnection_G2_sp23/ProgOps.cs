﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DatabaseConnection_G2_sp23
{
    class ProgOps
    {
        private const string CONNECT_STRING = @"Server=3.130.26.194;Database= inew2330gsp23; user Id= team2sp232330;" + "password= HF6ukL7sQs;";
        
        private static SqlConnection Database = new SqlConnection(CONNECT_STRING);
        
        private static SqlCommand sqlResultsCommand;
        
        private static SqlDataAdapter daResults = new SqlDataAdapter();
        
        private static DataTable dtResultsTable = new DataTable();

        public static DataTable DTresultsTable
        {
            get { return dtResultsTable; }
            set { dtResultsTable = value; }
        }
        public static void OpenDatabase()
        {
           
            Database.Open();
            
            MessageBox.Show("Connection to database was opened successfully", "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }
        public static void CloseDatabase()
        {
            
            Database.Close();
            
            Database.Dispose();
            MessageBox.Show("Connection to database was closed successfully", "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
