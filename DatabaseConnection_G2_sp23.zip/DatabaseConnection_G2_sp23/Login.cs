﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseConnection_G2_sp23
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            //opens database
            ProgOps.OpenDatabase();
        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            //closes database
            ProgOps.CloseDatabase();
            Application.Exit();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            //Application.Exit();
            this.Close();
        }
    }
}
